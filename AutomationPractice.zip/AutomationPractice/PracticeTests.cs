using NUnit.Framework;
using AutomationPractice.Library;
using OpenQA.Selenium.Interactions;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;
using OpenQA.Selenium.Support.UI;

namespace AutomationPractice
{
    public class Tests
    {
        private IWebDriver driver;
        [OneTimeSetUp]
        public void Initialization()
        {
            driver = new ChromeDriver(@"C:\Program Files\Google\Chrome\Application");
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(15);
        }
        [Test]
        public void AddProduct()
        {
            
            driver.Navigate().GoToUrl("http://automationpractice.com/");
            Thread.Sleep(2000);
            driver.FindElement(By.LinkText("WOMEN")).Click();
            Thread.Sleep(1000);
            

            IWebElement Size_Select_S = driver.FindElement(By.XPath("//*[@id='layered_id_attribute_group_1']"));
            IWebElement Composition_Select_Cotton = driver.FindElement(By.XPath("//*[@id='layered_id_feature_5']"));
            IWebElement Style_Select_Casual = driver.FindElement(By.XPath("//*[@id='ul_layered_id_feature_6']/li[1]/label/a"));
            IWebElement Blouse_Select_27 = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[2]/div/div[2]/div[1]/span"));
            IWebElement Blouse_27_AddCart = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[2]/div/div[2]/div[2]/a[1]/span"));
            
            IWebElement Checkout_Closewindow = driver.FindElement(By.XPath("//span[@title='Close window']"));
            

            

            Actions actions = new Actions(driver);
            actions.MoveToElement(Size_Select_S).Click().Perform();
            Thread.Sleep(1000);
            actions.MoveToElement(Composition_Select_Cotton).Click().Perform();
            Thread.Sleep(1000);
            actions.MoveToElement(Style_Select_Casual).Click().Perform();
            Thread.Sleep(1000);
            actions.MoveToElement(Blouse_Select_27).MoveToElement(Blouse_27_AddCart).Click().Perform();
            Thread.Sleep(1000);
            
            Thread.Sleep(1000);
            //ProceedTo_Checkout.Click();
            Thread.Sleep(1000);
            Checkout_Closewindow.Click();

            Thread.Sleep(1000);
            IWebElement Home_logo = driver.FindElement(By.XPath("//*[@id='header_logo']/a/img"));
            Home_logo.Click();
            Thread.Sleep(1000);
            driver.FindElement(By.LinkText("WOMEN")).Click();
            Thread.Sleep(1000);
            
            driver.FindElement(By.XPath("//*[@id='center_column']/ul/li/div/div[1]/div/a[1]/img")).Click();
          
            
            Thread.Sleep(3000);
           
            driver.SwitchTo().Frame(driver.FindElement(By.ClassName("fancybox-iframe")));
           
            IWebElement Sizedrpdwn = driver.FindElement(By.XPath("//*[@id='group_1']"));
            SelectElement oSelect = new SelectElement(Sizedrpdwn);
            oSelect.SelectByText("M");
            driver.FindElement(By.XPath("//*[@name='Blue']")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//p[@id='add_to_cart']")).Click();
            Thread.Sleep(1000);
            driver.SwitchTo().DefaultContent();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//*[@id='layer_cart']/div[1]/div[2]/div[4]/a")).Click();
           
            
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//*[@id='center_column']/p[2]/a[1]/span")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//*[@id='email']")).SendKeys("op@op.com");
            driver.FindElement(By.XPath("//*[@id='passwd']")).SendKeys("123456");
            driver.FindElement(By.XPath("//*[@id='SubmitLogin']/span")).Click();
            driver.FindElement(By.XPath("//span[contains(text(),'Update')]")).Click();
            Thread.Sleep(1000);

            driver.FindElement(By.XPath("//*[@id='firstname']")).Clear();
            driver.FindElement(By.XPath("//*[@id='firstname']")).SendKeys("rrt");
            driver.FindElement(By.XPath("//*[@id='lastname']")).Clear();
            driver.FindElement(By.XPath("//*[@id='lastname']")).SendKeys("tr");
            driver.FindElement(By.XPath("//*[@id='address1']")).Clear();
            driver.FindElement(By.XPath("//*[@id='address1']")).SendKeys("44");
            driver.FindElement(By.XPath("//*[@id='city']")).Clear();
            driver.FindElement(By.XPath("//*[@id='city']")).SendKeys("NY");
            IWebElement Statedrodown = driver.FindElement(By.XPath("//*[@id='id_state']"));
            SelectElement Stateselect = new SelectElement(Statedrodown);
            Stateselect.SelectByText("Florida");
            driver.FindElement(By.XPath("//*[@id='postcode']")).Clear();
            driver.FindElement(By.XPath("//*[@id='postcode']")).SendKeys("55555");
            driver.FindElement(By.XPath("//*[@id='phone_mobile']")).Clear();
            driver.FindElement(By.XPath("//*[@id='phone_mobile']")).SendKeys("5555555");
            driver.FindElement(By.XPath("//*[@id='submitAddress']")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//*[@name='processAddress']")).Click();
            Thread.Sleep(1000);

            //Proceed to checkout without accepting terms and consition and it would throw error and we are reading the error

            //payment screen cant enter any data as it has no option to enter incorrect data (only bank wire or check buttons) irrespectice of what you click takes to confirm order page
            driver.FindElement(By.XPath("//*[@name='processCarrier']")).Click();
            //driver.SwitchTo().Frame(driver.FindElement(By.ClassName("fancybox-error")));

            String expectedMessage = "You must agree to the terms of service before continuing.";
            String message = driver.FindElement(By.XPath("//*[@class='fancybox-error']")).Text;
            Assert.AreEqual(message, expectedMessage);
            driver.Close();
           


     









            //actions.MoveToElement(Productpage_size).Click().Perform();
            //Productpage_Blouse.Click();
            //Utilities.ClickElement("Productpage_Blouse");

            //actions.MoveToElement(ProceedTo_Checkout).Click().Perform();
            //Thread.Sleep(2000);
            //Utilities.ClickElement("ProceedTo_Checkout");
            //ProceedTo_Checkout.Click();
            //WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            //wait.Until(ExpectedConditions.ElementToBeClickable(ProceedTo_Checkout));
            //wait.Until(ExpectedConditions.elementToBeClickable(element));
            //ProceedTo_Checkout.Click();


            //WebElement womenTab = driver.findElement(By.linkText("WOMEN"));
            //CommonPage cp = new CommonPage(driver);
            //cp.ClickWomenCategory();
            //cp.ClickSizeS();
            //cp.ClickCompCotton();
            //cp.ClickStyleCasual();
        }
    }
}