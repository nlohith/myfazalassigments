﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AutomationPractice.Library
{
    class Utilities
    {
        public const int DefaultRetryAttempts = 10;
        //public Uri BaseUrl = new Uri(ConfigurationManager.AppSettings["BaseURL"] ?? "https://ultimateqa.com/automation/");
        //public static IWebDriver WebDriver;
        public static IWebDriver WebDriver;
        public static IWebDriver Instance { get; set; }
        //System.setProperty("webdriver.chrome.driver", "C:\\path\\to\\chromedriver.exe");
        
        public static void launchbrowser()
        {
            
            Instance = new ChromeDriver(@"C:\Program Files\Google\Chrome\Application");
            
            Instance.Navigate().GoToUrl("http://automationpractice.com");
            Instance.Manage().Window.Maximize();
            Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);

        }

        public static void ClickElement(String Name)
        {
            try
            {
                var data = Instance.FindElement(By.XPath(Name));
                data.Click();

            }

            catch (Exception)
            { }
        }

        public static void ClickCombo(String Name, String value)
        {
            try
            {
                var data = Instance.FindElement(By.XPath(Name));
                data.Click();

            }

            catch (Exception)
            { }
        }
        public static void ClickElementselect(String Name, String value)
        {
            try
            {

                var option = Instance.FindElement(By.Id(Name));
                var selectElement = new SelectElement(option);
                selectElement.SelectByText(value);

            }

            catch (Exception)
            { }

        }

        public static void WaitUntilPageReady()
        {
            try
            {
                long numBusyItems = 0;
                do
                {
                    IJavaScriptExecutor js = (IJavaScriptExecutor)WebDriver;
                    String documentStatus = (String)js.ExecuteScript("return document.readyState;");
                    var activeJqueryCount = Convert.ToInt16(js.ExecuteScript("return jQuery.active"));
                    var animationCount = Convert.ToInt16(js.ExecuteScript("return $(\":animated\").length;"));
                    var documentState = Convert.ToInt16(((documentStatus.Equals("complete")) ? 0 : 1));
                    numBusyItems = documentState + activeJqueryCount + animationCount;

                    Thread.Sleep(500);
                } while (numBusyItems > 1);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public static bool IsElementDisplayed(IWebElement element)
        {
            try
            {
                for (var i = 0; i < DefaultRetryAttempts; i++)
                {
                    if (element.Displayed)
                    {
                        return true;
                    }

                    WaitUntilPageReady();
                }

                Assert.Fail("Element not displayed");
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
